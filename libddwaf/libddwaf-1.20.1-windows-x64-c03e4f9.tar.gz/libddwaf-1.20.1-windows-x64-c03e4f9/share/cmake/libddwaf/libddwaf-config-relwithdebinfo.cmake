#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libddwaf_static" for configuration "RelWithDebInfo"
set_property(TARGET libddwaf_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libddwaf_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "C;CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/ddwaf_static.lib"
  )

list(APPEND _cmake_import_check_targets libddwaf_static )
list(APPEND _cmake_import_check_files_for_libddwaf_static "${_IMPORT_PREFIX}/lib/ddwaf_static.lib" )

# Import target "libddwaf_shared" for configuration "RelWithDebInfo"
set_property(TARGET libddwaf_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libddwaf_shared PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/ddwaf.lib"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/ddwaf.dll"
  )

list(APPEND _cmake_import_check_targets libddwaf_shared )
list(APPEND _cmake_import_check_files_for_libddwaf_shared "${_IMPORT_PREFIX}/lib/ddwaf.lib" "${_IMPORT_PREFIX}/lib/ddwaf.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
